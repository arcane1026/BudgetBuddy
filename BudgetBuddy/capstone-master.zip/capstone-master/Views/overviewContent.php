<div id="overviewContent">
    <?php
    //both of us worked on this
        $incomeO = 0;
        $expensesO = 0;

        $results = pullTableBalance($db);    
		
        foreach($results as $r) {
          if (($r['Amount'] > 0) && ($r['userID'] == $_SESSION["loggedInUserID"])){
            $incomeO += $r['Amount'];
          }
      
          if (($r['Amount'] < 0) && ($r['userID'] == $_SESSION["loggedInUserID"])){
            $expensesO += abs($r['Amount']);
          }
        }

        include_once("graph.php");
    ?>
    <br><br><br>
    <a id="overviewButtons" href="?action=incomePage">Income: $<?php echo $incomeO; ?></a>
    <br><br><br>
    <a id="overviewButtons" href="?action=expensesPage">Expenses: $<?php echo $expensesO; ?></a>
    <br><br><br>
    <a id="overviewButtons" href="?action=goalsPage">Goals</a>
</div>