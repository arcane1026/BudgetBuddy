<!DOCTYPE HTML>
<html>
<head>
<link rel="stylesheet" type="text/css" href="stylesheet.css">
</head>
<body>
    <h1 id="registerBB">Budget Buddy</h1>
    <!--Chris designed the register page-->
    <div id="registerPageContainer">
        <?php
        $loggedIn = filter_input(INPUT_GET, 'loggedIn',FILTER_SANITIZE_STRING) ?? "";


        if(session_status() == PHP_SESSION_NONE){
                session_start();
            }

            if(isset($_SESSION["loggedIn"])){
                ?>
                <meta http-equiv="refresh" content="0; URL='index.php'"/>
                <?php
            }

        ?>


        <h3 id="registerMotto">Keeping track of your finances so you don't have to</h3>

        <br><br>

        <form action="index.php" method="get" align="center">
            <input type="text" name="emailVar" id="emailVarRegister" pattern="[A-z,0-9]{2,}@[A-z]{2,}.[A-z]{2,}" title="example@email.com" placeholder="email" value="" required>

            <br><br>

            <input type="password" name="passwordVar" id="passwordVarRegister" placeholder="password" required>

            <br><br>

            <input type="password" name="passwordVarConfirm" id="passwordVarConfirmRegister" placeholder="confirm password" required>

            <br><br><br>

            <input type="submit" name="action" id="registerButton" value="Sign Up">
            <input type="hidden" name="action" id="registerButton" value="registerUser">

        </form>


            <p id="signupLinkLogin">Already have an account? <a id="registerLink" href="login.php">Log in here</a></p>
    </div>
</body>
</html>