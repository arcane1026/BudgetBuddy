<?php

$dsn = "mysql:host=ict.neit.edu:5500;dbname=budgetbuddy";
$userName = "BudgetBuddy";
$pWord = "neit2018";
try{
    $db = new PDO($dsn,$userName,$pWord);
}
catch(PDOException $e){
    die("Can't connect to the database.");
}
?>