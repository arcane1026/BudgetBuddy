<?php
//chris designed this
    if(isset($_POST['submitUsername']))
    {
        move_uploaded_file($_FILES['file']['tmp_name'],"../images/".$_FILES['file']['name']);
        $sql = ("UPDATE username SET username = :username, profilePicture ='".$_FILES['file']['name']."'WHERE usernameID = :usernameID");
        $sql = $db->prepare($sql);
        $sql->bindParam(':username',$_POST['username']);
        $sql->bindParam(':usernameID',$_SESSION['usernameIDupdate']);
        $sql->execute();

        $sql = "SELECT * FROM username WHERE usernameID = :usernameID";
        $sql = $db->prepare($sql);
        $sql->bindParam(':usernameID',$_SESSION['usernameIDupdate']);
        $sql->execute();
        $results = $sql->fetchAll(PDO::FETCH_ASSOC);

        foreach($results as $result)
        {
            $image = $result['profilePicture'];
            $username = $result['username'];
        }

        if($image == "")
        {
            $defaultImage = "../images/default.png";

            $sql = "UPDATE username SET profilePicture = :profilePicture WHERE usernameID = :usernameID";
            $sql = $db->prepare($sql);
            $sql->bindParam(':profilePicture',$defaultImage);
            $sql->bindParam(':usernameID', $_SESSION['usernameIDupdate']);
            $sql->execute();
        }

        if($username == "")
        {
            $defaultUsername = "username";

            $sql = "UPDATE username SET username = :username WHERE usernameID = :usernameID";
            $sql = $db->prepare($sql);
            $sql->bindParam(':username',$defaultUsername);
            $sql->bindParam(':usernameID', $_SESSION['usernameIDupdate']);
            $sql->execute();
        }

        ?>
            <meta http-equiv="refresh" content="0; URL='admincp.php?tableSelectList=username&action=Select+a+Table&action=tableSelectUpdate'"/>
        <?php
    }

    if($table == "username")
    {
        $sql = "SELECT * FROM username WHERE usernameID = :tableID";
        $sql = $db->prepare($sql);
        $sql->bindParam(':tableID',$tableID);
        $sql->execute();
        $results = $sql->fetchAll(PDO::FETCH_ASSOC);

        foreach($results as $result)
        {
            $_SESSION['userIDupdate'] = $result['userID'];
            $_SESSION['usernameIDupdate'] = $result['usernameID'];
            $_SESSION['usernameUpdate'] = $result['username'];
        }

        ?>
        <form action="" method="post" enctype="multipart/form-data">
            <input type="text" name="usernameID" value="<?php echo $_SESSION['usernameIDupdate']; ?>" readonly="readonly" />
            <input type="text" name="userID" value="<?php echo $_SESSION['userIDupdate']; ?>" readonly="readonly" />

            <input type="text" name="username" placeholder="Enter a username" value="<?php echo $_SESSION['usernameUpdate']; ?>" />
            <input type="file" name="file">

            <input type="submit" name="submitUsername">

        </form>
    <?php
    }

    if($table == "balance")
    {
        $sql = "SELECT * FROM balance WHERE balanceID = :tableID";
        $sql = $db->prepare($sql);
        $sql->bindParam(':tableID',$tableID);
        $sql->execute();
        $results = $sql->fetchAll(PDO::FETCH_ASSOC);

        foreach($results as $result)
        {
            $_SESSION['balanceIDupdate'] = $result['balanceID'];
            $_SESSION['userIDupdate'] = $result['userID'];
            $_SESSION['titleUpdate'] = $result['Title'];
            $_SESSION['amountUpdate'] = $result['Amount'];
            $_SESSION['payIntervalUpdate'] = $result['payInterval'];
            $_SESSION['notesUpdate'] = $result['Notes'];
            $_SESSION['dateUpdate'] = $result['Date'];
        }
        ?>

        <form action="admincp.php" method="GET">
            <input type="text" name="balanceID" value="<?php echo $_SESSION['balanceIDupdate']; ?>" readonly="readonly" />
            <input type="text" name="userID" value="<?php echo $_SESSION['userIDupdate']; ?>" readonly="readonly" />

            <input type="text" name="title" placeholder="title" value="<?php echo $_SESSION['titleUpdate']; ?>" required />
            <input type="text" name="amount" placeholder="amount" value="<?php echo $_SESSION['amountUpdate']; ?>" required />
            <input type="text" name="payInterval" placeholder="pay interval" value="<?php echo $_SESSION['payIntervalUpdate']; ?>" required />
            <input type="text" name="notes" placeholder="notes" value="<?php echo $_SESSION['notesUpdate']; ?>" required />
            <input type="date" name="date" placeholder="date" value="<?php echo $_SESSION['dateUpdate']; ?>" required />

            <input type="submit" name="action" value="Submit"> 
            <input type="hidden" name="action" id="expensesButton" value="balanceUpdate">
        </form>
    <?php
    }

    if($table == "goals")
    {
        $sql = "SELECT * FROM goals WHERE goalsID = :tableID";
        $sql = $db->prepare($sql);
        $sql->bindParam(':tableID',$tableID);
        $sql->execute();
        $results = $sql->fetchAll(PDO::FETCH_ASSOC);

        foreach($results as $result)
        {
            $_SESSION['goalsIDupdate'] = $result['goalsID'];
            $_SESSION['userIDupdate'] = $result['userID'];
            $_SESSION['titleUpdate'] = $result['title'];
            $_SESSION['amountUpdate'] = $result['amount'];
            $_SESSION['goalDateUpdate'] = $result['goalDate'];
            $_SESSION['notesUpdate'] = $result['notes'];
            $_SESSION['priorityUpdate'] = $result['priority'];
        }
        ?>

        <form action="admincp.php" method="GET">
            <input type="text" name="goalsID" value="<?php echo $_SESSION['goalsIDupdate']; ?>" readonly="readonly" />
            <input type="text" name="userID" value="<?php echo $_SESSION['userIDupdate']; ?>" readonly="readonly" />

            <input type="text" name="title" placeholder="title" value="<?php echo $_SESSION['titleUpdate']; ?>" required />
            <input type="text" name="amount" placeholder="amount" value="<?php echo $_SESSION['amountUpdate']; ?>" required />
            <input type="date" name="goalDate" placeholder="goal date" value="<?php echo $_SESSION['goalDateUpdate']; ?>" required />
            <input type="text" name="notes" placeholder="notes" value="<?php echo $_SESSION['notesUpdate']; ?>" />
            <input type="text" name="priority" placeholder="priority" value="<?php echo $_SESSION['priorityUpdate']; ?>" required />

            <input type="submit" name="action" value="Submit"> 
            <input type="hidden" name="action" id="expensesButton" value="goalsUpdate">
        </form>
    <?php
    }

    if($table == "users")
    {
        $sql = "SELECT * FROM users WHERE userID = :tableID";
        $sql = $db->prepare($sql);
        $sql->bindParam(':tableID',$tableID);
        $sql->execute();
        $results = $sql->fetchAll(PDO::FETCH_ASSOC);

        foreach($results as $result)
        {
            $_SESSION['userIDupdate'] = $result['userID'];
            $_SESSION['emailUpdate'] = $result['email'];
            $_SESSION['passwordUpdate'] = $result['password'];
            $_SESSION['userCreationDateUpdate'] = $result['userCreationDate'];
        }
        ?>

        <form action="admincp.php" method="GET">
            <input type="text" name="userID" value="<?php echo $_SESSION['userIDupdate']; ?>" readonly="readonly" />

            <input type="text" name="email" placeholder="email" value="<?php echo $_SESSION['emailUpdate']; ?>" required />
            <input type="text" name="password" placeholder="password" value="" />

            <input type="submit" name="action" value="Submit"> 
            <input type="hidden" name="action" id="expensesButton" value="usersUpdate">
        </form>
    <?php
    }


?>