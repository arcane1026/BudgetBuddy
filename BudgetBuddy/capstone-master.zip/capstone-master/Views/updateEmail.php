<!--chris designed this-->
<a id="backButton" href="index.php?action=userSettings">Back</a>

<div id="userpicChangeContainer">

    
    <form action="index.php" method="get">
    
        

        <input type="text" name="emailVar" id="emailUpdateInput" pattern="[A-z,0-9]{2,}@[A-z]{2,}.[A-z]{2,}"
        title="example@email.com" placeholder="email" value="" required>

        <input type="password" name="passwordVar" id="passwordUpdateInput" placeholder="password" required>

        <h5 id="usernameChangeID">User ID: <?php echo $_SESSION["loggedInUserID"] ?></h5>


        <input type="submit" id="usernameChangeInputSubmit" name="action" value="Submit">
        <input type="hidden" name="action" id="updateEmailSubmit" value="updateEmailSubmit">


    </form>
</div>