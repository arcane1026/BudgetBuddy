<?php
//chris designed this
?>


<table id="dataTableAdmin">

    <tr>
        <?php
        foreach($columnNameArray as $col)
        {
            foreach($col as $c)
            {
                ?><th><?php echo $c; ?></th><?php
                
            }
            
        }
        ?><th>Delete</th><?php
        ?>
    </tr>

    <?php

    foreach($data as $da)
    {
        ?>
        <tr>
        <?php
        foreach($da as $d)
        {
            ?><td><?php echo $d ?></td><?php
        }
        ?>
        <td><a href="adminCP.php?table=<?php echo $tableSelectList ?>&tableID=<?php
        if($tableSelectList == "balance")
        {
            echo $da["balanceID"];
        }
        if($tableSelectList == "goals")
        {
            echo $da["goalsID"];
        }
        if($tableSelectList == "username")
        {
            echo $da["usernameID"];
        }
        if($tableSelectList == "users")
        {
            echo $da["userID"];
        } 
        ?>&action=deleteTableData">Delete</a></td>
        </tr>
        <?php
    }

    ?>




</table>