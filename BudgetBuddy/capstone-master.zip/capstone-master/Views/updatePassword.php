<!--chris designed this-->
<a id="backButton" href="index.php?action=userSettings">Back</a>

<div id="userpicChangeContainer">

    
    <form action="index.php" method="get">
    
        

        <input type="password" name="oldPasswordVar" id="oldPasswordField" placeholder="old password" required>

        <input type="password" name="passwordVar" id="passwordUpdateInput" placeholder="new password" required>
        <input type="password" name="passwordVarConfirm" id="passwordUpdateInput" placeholder="confirm password" required>

        <h5 id="usernameChangeID">User ID: <?php echo $_SESSION["loggedInUserID"] ?></h5>



        <input type="submit" id="usernameChangeInputSubmit" name="action" value="Submit">
        <input type="hidden" name="action" id="updatePasswordSubmit" value="updatePasswordSubmit">


    </form>
</div>