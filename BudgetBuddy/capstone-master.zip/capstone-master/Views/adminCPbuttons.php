<!--chris designed this-->
<form action="index.php" method="get" enctype="multipart/form-data">
    <a id="adminBtn" href="?action=AddData">Add Data</a>
    <br><br>
    <a id="adminBtn" href="?action=PullData">Pull Data</a>
    <br><br>
    <a id="adminBtn" href="?action=UpdateData">Update Data</a>
    <br><br>
    <a id="adminBtn" href="?action=DeleteData">Delete Data</a>
</form>