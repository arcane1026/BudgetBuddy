<!--both of us worked on this-->
<a id="backButton" href="index.php">Back</a>
<div id="userSettingsContainer">

  <?php

	 
    $profilePicture = profilePicPull($db,$_SESSION["loggedInUserID"]);
    
    ?>

    <img width="200" height="200" src="../images/<?php echo $profilePicture ?>" alt="profile picture">

    <div id="userSettingsNameEdit">
        
    <h2 id="usernameH2">
        <?php 
            $results = usernamePull($db);

            if(!empty($results)){
                echo end($results[0]);
            }
            else{
                echo "username";
            }
        ?>
    </h2>
    
    <a id="editBtnUser" href="index.php?action=usernameChange">Edit</a>

    <br><br><br><br><br><br>
    
    <h3 id="userIDH3">User ID: <?php echo $_SESSION["loggedInUserID"] ?></h3>
    
    </div>

    <a id="editBtnUser2" href="index.php?action=userPictureChange">Edit</a>

    <br><br><br>

    <div id="userSettingsButtons1">
        <a id="userSettingsButtons" href="index.php?action=updateEmail">Update Email</a>
    </div>

    <br><br><br>

    <div id="userSettingsButtons2">
        <a id="userSettingsButtons" href="index.php?action=updatePassword">Change Password</a>
    </div>

    <br><br>

    <div id="userSettingsButton3">
        <a id="deleteAccountBtn" href="index.php?action=deleteAccount">DELETE ACCOUNT</a>
    </div>
    

</div>