<!DOCTYPE HTML>
<html>
<head>

<link rel="stylesheet" type="text/css" href="stylesheet.css">
</head>
<body>
<?php
//both of us designed this page
session_start();

$loggedIn = filter_input(INPUT_GET, 'loggedIn',FILTER_SANITIZE_STRING) ?? "";

if(isset($_SESSION["loggedIn"])){
    ?>
    <meta http-equiv="refresh" content="0; URL='index.php'"/>
    <?php
}
?>

<div id="landingPageContainer">
    <h1 id="headerBB">Budget Buddy</h1>
    <h3 id="BBmotto">Keeping track of your finances so you don't have to</h3>

    <a id="landingLogin" href="login.php">LOGIN</a>
    <a id="landingSignup" href="Register.php">SIGNUP</a>
</div>
</body>
</html>