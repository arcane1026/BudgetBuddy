<!DOCTYPE HTML>
<html>
<head>
<link rel="stylesheet" type="text/css" href="stylesheet.css">
</head>

<body>
<!--Chris designed the login page-->
<h1 id="loginBB">Budget Buddy</h1>

<div id="loginPageContainer">

<?php
$loggedIn = filter_input(INPUT_GET, 'loggedIn',FILTER_SANITIZE_STRING) ?? "";

session_start();

if(session_status() == PHP_SESSION_NONE){
        session_start();
    }

    if(!isset($_SESSION["loggedIn"]))
    {
        $_SESSION["loggedIn"] = null;
    }

    echo $_SESSION["loggedIn"];

    if(isset($_SESSION["loggedIn"])){
        ?>
        <meta http-equiv="refresh" content="0; URL='index.php'"/>
        <?php
    }

    ?>


    <h3 id="loginMotto">Keeping track of your finances so you don't have to</h3>

    <form action="index.php" method="get" align="center">
        <input type="text" name="emailVar" id="emailVarLogin" pattern="[A-z,0-9]{2,}@[A-z]{2,}.[A-z]{2,}"
        title="example@email.com" placeholder="email" value="" required>

            <br><br>

        <input type="password" name="passwordVar" id="passwordVarLogin" placeholder="password" required>

            <br><br><br>

        <input type="submit" name="action" id="loginButton" value="Login">


    </form>

<p id="signupLinkLogin">Don't have an account? <a id="registerLink" href="register.php">Sign up for free now</a></p>
</div>
</body>
</html>