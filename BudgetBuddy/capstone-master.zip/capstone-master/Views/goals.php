<?php
    include_once("header.php");
    //both of us worked on this
?>

<br><br>

<form action="index.php" method="get">
    <table id="incomeTable">

        <tr>
            <th>Title</th>
            <th>Amount</th>
            <th>Priority</th>
            <th>Notes</th>
            <th>Goal Date</th>
        </tr>
        <?php

            foreach($goalsDB as $goalsD)
            {
                ?>
                <tr>

                    <td id="incomeTableCOL">

                        <?php

                            echo $goalsD['title'];

                        ?>

                    </td>

                    <td id="incomeTableCOL">

                        <?php

                        echo $goalsD['amount'];

                        ?>

                    </td>
                    <td id="incomeTableCOL">

                        <?php

                        echo $goalsD['priority'];

                        ?>

                    </td>

                    <td id="incomeTableCOL">

                        <?php

                        echo $goalsD['notes'];

                        ?>

                    </td>
                    
                    <td id="incomeTableCOL">

                        <?php

                        echo $goalsD['goalDate'];

                        ?>

                    </td>

                </tr>

                <?php
            }
        ?>

        <tr>
            <td>
                <input type="text" name="titleVar" placeholder="Title" required />
            </td>
            <td>
                <input type="text" name="amountVar" placeholder="Amount" required />
            </td>
            <td>
                <select name="prioritySelectList">
                    <option selected="selected">choose an option</option>
                    <option value="1">1</option>
                    <option value="2">2</option>
                    <option value="3">3</option>
                </select>
            </td>
            <td>
                <input type="text" name="notesVar" placeholder="Notes" />
            </td>
            
            <td>
                <input type="date" name="goalDateVar" placeholder="Interval" required />
            </td>
            </tr>

            <tr>
                <td>
                    <input type="submit" name="action" value="Submit">
                    <input type="hidden" name="action" id="expensesButton" value="goalsSubmit">
                </td>
            </tr>


    </table>
</form>

