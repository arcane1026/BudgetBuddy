<form action="adminCP.php" method="get">

    <?php
    //chris designed this
        if($data) {
            $columns = count(current($data));

            ?>

            <table id="dataTableAdmin">

                <tr>
                    <?php
                    foreach($columnNameArray as $columnName)
                    {
                        foreach($columnName as $column)
                        {

                        ?>

                        <th><?php echo $column ?></th>

                        <?php
                        }               
                    }
                    ?>
                </tr>

                <tr>
                <?php       
                foreach ($data as $da) {
                    foreach ($columnNameArray as $columnName) {
                        foreach ($columnName as $column) {
                            ?>
                            <td><?php echo $da[$column] ?></td>

                            <?php
                            
                        }

                        ?>
                        <?php

                    }
                    ?>

                    </tr>
                    <?php
                }
                }
        else{
            echo "Table did not load properly.";
        }

                ?>


            </table>
        </form>