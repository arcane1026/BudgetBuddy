<link rel="stylesheet" type="text/css" href="stylesheet.css">

<?php
    //chris worked on this
    if(!isset($_SESSION[""])){
        session_start();
    }

    unset($_SESSION["loggedInUsername"]);
    unset($_SESSION["loggedIn"]);
    unset($_SESSION["loggedInUserID"]);


?>
<br>
<meta http-equiv="refresh" content="0; URL='landingPage.php'"/>
