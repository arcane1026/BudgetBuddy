<!--chris designed this-->
<?php
    $sql = "SHOW TABLES";
    $sql = $db->prepare($sql);
    $sql->execute();
    $results = $sql->fetchAll(PDO::FETCH_ASSOC);

    ?>
        <h3>current tables in database:</h3>
    <?php

    foreach($results as $r){
        foreach($r as $re)
        {
            print_r($re);
            echo "<br>";
        }
    }
?>

<hr>

<h3>Add to the balance table: </h3>

<form action="adminCP.php" method="get">

    <input type="text" name="userID" placeholder="Enter a user ID" value="" required />
    <input type="text" name="title" placeholder="Enter title" value="" required />
    <input type="text" name="amount" placeholder="Enter amount" value="" required />
    <input type="text" name="interval" placeholder="Enter interval" value="" required />
    <input type="text" name="notes" placeholder="Enter notes" value="" />
    <input type="date" name="date" value="" required />

    <input type="submit" name="action" value="Submit Balance">
    <input type="hidden" name="action" id="expensesButton" value="submitBalance">


</form>

<hr>

<h3>Add to the goals table: </h3>

<form action="adminCP.php" method="get">

    <input type="text" name="userID" placeholder="Enter a user ID" value="" required />
    <input type="text" name="title" placeholder="Enter title" value="" required />
    <input type="text" name="amount" placeholder="Enter amount" value="" required />
    <input type="text" name="priority" placeholder="Enter priority" value="1" required />
    <input type="text" name="notes" placeholder="Enter notes (optional)" value="" />
    <input type="date" name="goalDate" placeholder="Enter goal date" value="" required />

    <input type="submit" name="action" value="Submit Goal">
    <input type="hidden" name="action" id="expensesButton" value="submitGoal">


</form>

<hr>

<h3>Add to the users table: </h3>

<form action="adminCP.php" method="get">

    <input type="text" name="email" id="email" pattern="[A-z,0-9]{2,}@[A-z]{2,}.[A-z]{2,}" title="example@email.com" placeholder="email" value="" required>
    <input type="password" name="password" id="password" placeholder="password" required>

    <input type="submit" name="action" value="Submit User">
    <input type="hidden" name="action" id="expensesButton" value="submitUser">


</form>

<hr>

<h3>Add to the username table: </h3>

<form action="adminCP.php" method="get">

    <input type="text" name="userID" placeholder="Enter a user ID" value="" required />
    <input type="text" name="username" placeholder="Enter a username" value="" required />
    <select name="pictureCategory">
        <option value="../images/default.png">Choose a category</option>
        <option id="listOption" value="../images/red.png">Red</option>
        <option id="listOption" value="../images/blue.png">Blue</option>
        <option id="listOption" value="../images/green.png">Green</option>
        <option id="listOption" value="../images/default.png">Yellow</option>
        <option id="listOption" value="../images/orange.png">Orange</option>
        <option id="listOption" value="../images/lightblue.png">Light Blue</option>
        <option id="listOption" value="../images/purple.png">Purple</option>
        <option id="listOption" value="../images/pink.png">Pink</option>
    </select>



    <input type="submit" name="action" value="Submit Username">
    <input type="hidden" name="action" id="expensesButton" value="submitUsername">


</form>

<hr>