<a id="backButton" href="index.php?action=userSettings">Back</a>
<!--Angelo designed this-->
<?php
	if(isset($_POST['submit'])){
		$sql = "SELECT * FROM username WHERE userID = :userID";
		$sql = $db->prepare($sql);
		$sql->bindParam(':userID',$_SESSION["loggedInUserID"]);
		$sql->execute();
		$results = $sql->fetchAll(PDO::FETCH_ASSOC);

		foreach($results as $result)
		{
			if(!isset($result))
			{
				move_uploaded_file($_FILES['file']['tmp_name'],"../images/".$_FILES['file']['name']);
				$sql = "INSERT INTO username SET username = :username, profilePicture = '".$_FILES['file']['name']."', userID = :userID";
				$sql = $db->prepare($sql);
				$sql->bindParam(':username',"username");
				$sql->bindParam(':profilePicture',$profilePoc);
				$sql->bindParam(':userID', $_SESSION["loggedInUserID"]);
				$sql->execute();
			}

			else{
				move_uploaded_file($_FILES['file']['tmp_name'],"../images/".$_FILES['file']['name']);
				$sql = ("UPDATE username SET profilePicture ='".$_FILES['file']['name']."'WHERE userID = '".$_SESSION['loggedInUserID']."'");
				$sql = $db->prepare($sql);
				$sql->execute();
			}
		}

		
		
		?>
			<meta http-equiv="refresh" content="0; URL='index.php?action=userSettings'"/>
        <?php
	}
?>
<!DOCTYPE HTML>
<html>
	<head>
    
	</head>

<body>
<form action ="" method ="post" enctype="multipart/form-data">
	<input type = "file" name = "file" required>
	<input type = "submit" name = "submit">
</form>
<?php

	$profilePicture = profilePicPull($db,$_SESSION["loggedInUserID"]);
	
	?>

	<img width="200" height="200" src="../images/<?php echo $profilePicture ?>" alt="profile picture">

	</body>
</html>