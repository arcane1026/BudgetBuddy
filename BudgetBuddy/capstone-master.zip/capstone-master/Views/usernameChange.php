<!--chris designed this-->
<a id="backButton" href="index.php?action=userSettings">Back</a>
<div id="usernameChangeContainer">

    <form action="index.php" method="get">

        <input type="text" maxlength="11" id="usernameChangeInput" name="username" placeholder="Enter a username" value="" />

        <h5 id="usernameChangeID">User ID: <?php echo $_SESSION["loggedInUserID"] ?></h5>

        <input type="submit" id="usernameChangeInputSubmit" name="action" value="Submit">
        <input type="hidden" name="action" id="usernameChangeInputSubmit" value="submitUsername">


    </form>

</div>