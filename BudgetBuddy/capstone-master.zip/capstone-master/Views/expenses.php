<?php
    include_once("header.php");
    //both of us worked on this
?>

<br><br>

<form action="index.php" method="get">
    <table id="incomeTable">

        <tr>
            <th>Title</th>
            <th>Amount</th>
            <th>Interval</th>
            <th>Notes</th>
            <th>Date</th>
        </tr>
        <?php

            foreach($expensesDB as $expensesD)
            {
                ?>
                <tr>

                    <td id="incomeTableCOL">

                        <?php

                            echo $expensesD['Title'];

                        ?>

                    </td>

                    <td id="incomeTableCOL">

                        <?php

                        echo ($expensesD['Amount'] * -1);

                        ?>

                    </td>
                    <td id="incomeTableCOL">

                        <?php

                        echo $expensesD['payInterval'];

                        ?>

                    </td>

                    <td id="incomeTableCOL">

                        <?php

                        echo $expensesD['Notes'];

                        ?>

                    </td>

                    <td id="incomeTableCOL">

                        <?php

                        echo $expensesD['Date'];

                        ?>

                    </td>

                </tr>

                <?php
            }
        ?>

        <tr>
            <td>
                <input type="text" name="titleVar" placeholder="Title" required />
            </td>
            <td>
                <input type="text" name="amountVar" placeholder="Amount" required />
            </td>
            <td>
                <input type="text" name="intervalVar" placeholder="Interval" required />
            </td>
            <td>
                <input type="text" name="notesVar" placeholder="Notes" />
            </td>
            <td>
                <input type="date" name="dateVar" required />
            </td>
            </tr>

            <tr>
                <td>
                    <input type="submit" name="action" value="Submit"> 
                    <input type="hidden" name="action" id="expensesButton" value="expensesSubmit">

                </td>
            </tr>


    </table>
</form>

