<a id="backButton" href="index.php?action=userSettings">Back</a>

<div id="userpicChangeContainer">

    <h2>You are about to delete your account.</h1>

    <h2>This action CANNOT be undone.</h1>

    <h1>Are you sure you want to delete your account?</h1>

    <a id="deleteAccountBtn" href="index.php?action=userSettings" style="background-color:#30b582;">NO, GO BACK</a>

    <a id="deleteAccountBtn" href="index.php?action=deleteAccountSure">YES DELETE MY ACCOUNT</a>





</div>