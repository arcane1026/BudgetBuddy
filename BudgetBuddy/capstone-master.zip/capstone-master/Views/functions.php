<?php

    //Chris designed the database connection functions
    function pullTableUsers($db){
        $sql = "SELECT * FROM users";
        $sql = $db->prepare($sql);
        $sql->execute();
        $results = $sql->fetchAll(PDO::FETCH_ASSOC);
        return $results;
    }
    function pullTableBalance($db){
        $sql = "SELECT * FROM balance";
        $sql = $db->prepare($sql);
        $sql->execute();
        $results = $sql->fetchAll(PDO::FETCH_ASSOC);
        return $results;
    }

    function pullTableIncome($db){
        $userIDVar = $_SESSION["loggedInUserID"];
        $sql = "SELECT * FROM balance WHERE amount > 0 AND userID = :userID";
        $sql = $db->prepare($sql);
        $sql->bindParam(':userID', $_SESSION["loggedInUserID"]);
        $sql->execute();
        $results = $sql->fetchAll(PDO::FETCH_ASSOC);
        return $results;
    }

    function pullTableExpenses($db){
        $userIDVar = $_SESSION["loggedInUserID"];
        $sql = "SELECT * FROM balance WHERE amount < 0 AND userID = :userID";
        $sql = $db->prepare($sql);
        $sql->bindParam(':userID', $_SESSION["loggedInUserID"]);
        $sql->execute();
        $results = $sql->fetchAll(PDO::FETCH_ASSOC);
        return $results;
    }

    function pullTableGoals($db){
        $sql = "SELECT * FROM goals WHERE userID = :userID";
        $sql = $db->prepare($sql);
        $sql->bindParam(':userID',$_SESSION['loggedInUserID']);
        $sql->execute();
        $results = $sql->fetchAll(PDO::FETCH_ASSOC);
        return $results;
    }

    function pullTableUsername($db){
        $sql = "SELECT * FROM username";
        $sql = $db->prepare($sql);
        $sql->execute();
        $results = $sql->fetchAll(PDO::FETCH_ASSOC);
        return $results;
    }

    function incomeSubmit($db,$titleVar,$amountVar,$intervalVar,$notesVar,$dateVar){
        try {
            $sql = "INSERT INTO balance VALUES (NULL,:userID, :title, :amount, :interval, :notes, :date)";
            $sql = $db->prepare($sql);
            $sql->bindParam(':userID', $_SESSION["loggedInUserID"]);
            $sql->bindParam(':title', $titleVar);
            $sql->bindParam(':amount', $amountVar);
            $sql->bindParam(':interval', $intervalVar);
            $sql->bindParam(':notes', $notesVar);
            $sql->bindParam(':date', $dateVar);
            $sql->execute();
            ?>

            <meta http-equiv="refresh" content="0; URL='index.php?action=incomePage'"/>

            <?php
        }
        catch(PDOException $err){
            die("There was an error adding the information into the database.");
        }

    }

    function expensesSubmit($db,$titleVar,$amountVar,$intervalVar,$notesVar,$dateVar){
        $amountVar *= -1;

        try {
            $sql = "INSERT INTO balance VALUES (NULL,:userID, :title, :amount, :interval, :notes, :date)";
            $sql = $db->prepare($sql);
            $sql->bindParam(':userID', $_SESSION["loggedInUserID"]);
            $sql->bindParam(':title', $titleVar);
            $sql->bindParam(':amount', $amountVar);
            $sql->bindParam(':interval', $intervalVar);
            $sql->bindParam(':notes', $notesVar);
            $sql->bindParam(':date', $dateVar);
            $sql->execute();
            ?>

            <meta http-equiv="refresh" content="0; URL='index.php?action=expensesPage'"/>

            <?php
        }
        catch(PDOException $err){
            die("There was an error adding the information into the database.");
        }

    }

    function goalsSubmit($db,$titleVar,$amountVar,$prioritySelectList,$notesVar,$goalDateVar){
        try {
            $sql = "INSERT INTO goals VALUES (NULL,:userID, :title, :amount, :goalDate, :notes, :priority)";
            $sql = $db->prepare($sql);
            $sql->bindParam(':userID', $_SESSION["loggedInUserID"]);
            $sql->bindParam(':title', $titleVar);
            $sql->bindParam(':amount', $amountVar);
            $sql->bindParam(':goalDate', $goalDateVar);
            $sql->bindParam(':notes', $notesVar);
            $sql->bindParam(':priority', $prioritySelectList);
            $sql->execute();
            ?>

            <meta http-equiv="refresh" content="0; URL='index.php?action=goalsPage'"/>

            <?php
        }
        catch(PDOException $err){
            die("There was an error adding the information into the database.");
        }
    }

    function registerUserFunc($db,$email,$pword,$pword2){
        $sql = "SELECT * FROM users";
        $sql = $db->prepare($sql);
        $sql->execute();
        $results = $sql->fetchAll(PDO::FETCH_ASSOC);

        $boolVar = true;

        foreach($results as $result){
            if($email == $result['email']){
                $boolVar = false;
            }
        }

        if($pword == $pword2) {
            if ($boolVar) {
                try {
                    $pwordHash = hash('sha1', $pword);
                    $sql = "INSERT INTO users VALUES(null, :email,:password,NOW())";
                    $sql = $db->prepare($sql);
                    $sql->bindParam(':email', $email);
                    $sql->bindParam(':password', $pwordHash);
                    $sql->execute();

                    $sql = "SELECT userID FROM users WHERE email = :email";
                    $sql = $db->prepare($sql);
                    $sql->bindParam(':email',$email);
                    $sql->execute();
                    $results = $sql->fetchAll(PDO::FETCH_ASSOC);

                    foreach($results as $result){
                        $userID = $result['userID'];
                    }

                    $username = "username";
                    $picture = "../images/default.png";

                    $sql = "INSERT INTO username VALUES (NULL, :userID,:username,:picture)";
                    $sql = $db->prepare($sql);
                    $sql->bindParam(':userID',$userID);
                    $sql->bindParam(':username',$username);
                    $sql->bindParam(':picture',$picture);                    
                    $sql->execute();

                    echo "<br>user successfully created!";
                    ?>

                        <br><br>

                    <meta http-equiv="refresh" content="0; URL='login.php'"/>

                    <?php
                } catch (PDOException $err) {
                    die("There was an error adding the user to the database.");
                }
            } else {
                ?>
                <p>That email is already in use.</p>
                <?php
                include_once('register.php');

            }
        }
        else{
            ?>
                <p>Passwords do not match.</p>
            <?php
            include_once('register.php');
        }
    }

    function loginUserFunc($db,$email,$pword){
        $sql = "SELECT * FROM users WHERE email = :email";
        $sql = $db->prepare($sql);
        $sql->bindParam(':email',$email);
        $sql->execute();
        $results = $sql->fetch(PDO::FETCH_ASSOC);

        $pwordHash = hash('sha1',$pword);

        if($email == $results['email'] && $pwordHash == $results['password']){
            ?>
                <p>Logged in!</p>
            <?php
            $_SESSION['loggedIn'] = true;
            $_SESSION["loggedInUsername"] = $email;
            $_SESSION["loggedInUserID"] = $results["userID"];
            ?>
            <br><br>
            <meta http-equiv="refresh" content="0; URL='index.php'"/>
            <br><br>
            <?php
        }

        else{
            ?>
            <p>Incorrect username / password!</p>
            <meta http-equiv="refresh" content="0; URL='login.php'"/>
            <?php
        }
    }

    function addToBalance($db,$userID,$title,$amount,$interval,$notes,$date){
        try {
            $sql = "INSERT INTO balance VALUES(NULL, :userID, :title, :amount, :interval, :notes, :date)";
            $sql = $db->prepare($sql);
            $sql->bindParam(':userID', $userID);
            $sql->bindParam(':title', $title);
            $sql->bindParam(':amount', $amount);
            $sql->bindParam(':interval', $interval);
            $sql->bindParam(':notes', $notes);
            $sql->bindParam(':date', $date);
            $sql->execute();
        }
        catch(PDOException $e){
            die("There was an error...");
        }
    }

    function addToGoals($db,$userID,$title,$amount,$priority,$notes,$goalDate){
        try {
            $sql = "INSERT INTO goals VALUES (NULL, :userID, :title, :amount, :goalDate, :notes, :priority)";
            $sql = $db->prepare($sql);
            $sql->bindParam(':userID',$userID);
            $sql->bindParam(':title',$title);
            $sql->bindParam(':amount',$amount);
            $sql->bindParam(':goalDate',$goalDate);
            $sql->bindParam(':notes',$notes);
            $sql->bindParam(':priority',$priority);
            $sql->execute();
        }
        catch(PDOException $e){
            die("There was an error...");
        }
    }

    function addToUsers($db,$email,$pword){
        $sql = "SELECT * FROM users";
        $sql = $db->prepare($sql);
        $sql->execute();
        $results = $sql->fetchAll(PDO::FETCH_ASSOC);

        $boolVar = true;

        foreach($results as $result){
            if($email == $result['email']){
                $boolVar = false;
            }
        }

        if ($boolVar) {
            try {
                $pwordHash = hash('sha1', $pword);
                $sql = "INSERT INTO users VALUES(null, :email,:password,NOW())";
                $sql = $db->prepare($sql);
                $sql->bindParam(':email', $email);
                $sql->bindParam(':password', $pwordHash);
                $sql->execute();

                echo "User successfully created.";

                ?>
                <meta http-equiv="refresh" content="0; URL='adminCP.php'"/>
                <?php
            } catch (PDOException $e) {
                die("There was an error");
            }
        }
        else{
            echo "email is already in use.";
        }


    }

    function getColumnNames($db,$tableNames){
        $sql = "SELECT `COLUMN_NAME` FROM `INFORMATION_SCHEMA` . `COLUMNS` WHERE `TABLE_SCHEMA` = 'budgetbuddy' AND `TABLE_NAME` = :tableName";
        $sql = $db->prepare($sql);
        $sql->bindParam(':tableName',$tableNames);
        $sql->execute();
        $results = $sql->fetchAll(PDO::FETCH_ASSOC);
        return $results;
    }

    function submitUsernameFunc($db,$username){
        if(!$username)
        {
            $username = "username";
        }

        $sql = "SELECT * FROM username WHERE userID = :userID";
        $sql = $db->prepare($sql);
        $sql->bindParam(':userID', $_SESSION["loggedInUserID"]);
        $sql->execute();
        $results = $sql->fetchAll(PDO::FETCH_ASSOC);

        foreach($results as $re){
            if($re['userID'] == $_SESSION["loggedInUserID"])
            {
                $pictureThing = $re['profilePicture'];
            }
        }

        $sql = "DELETE FROM username WHERE userID = :userID";
        $sql = $db->prepare($sql);
        $sql->bindParam(':userID',$_SESSION["loggedInUserID"]);
        $sql->execute();

        if(!$pictureThing)
        {
            $pictureThing = "../images/default.png";
        }

        try{
            $sql = "INSERT INTO username VALUES (NULL, :userID,:username,:picture)";
            $sql = $db->prepare($sql);
            $sql->bindParam(':userID', $_SESSION["loggedInUserID"]);
            $sql->bindParam(':username', $username);
            $sql->bindParam(':picture', $pictureThing);
            $sql->execute();           
        }
        catch(PDOException $e)
        {
            die("There was an error updating your username.");
        }

        $pictureThing = null;
        $username = null;
        
        ?>
        
        <meta http-equiv="refresh" content="0; URL='index.php?action=userSettings'"/>

        <?php

    }

    function usernamePull($db){
        $sql = "SELECT username from username WHERE userID = :userID";
        $sql = $db->prepare($sql);
        $sql->bindParam(':userID', $_SESSION["loggedInUserID"]);
        $sql->execute();
        $results = $sql->fetchAll(PDO::FETCH_ASSOC);
        return $results;
    }

    //Angelo designed the profile picture submission functions
    function submitProfilePicture($db,$pictureThing){
        $sql = "SELECT * FROM username WHERE userID = :userID";
        $sql = $db->prepare($sql);
        $sql->bindParam(':userID', $_SESSION["loggedInUserID"]);
        $sql->execute();
        $results = $sql->fetchAll(PDO::FETCH_ASSOC);

        foreach($results as $re){
            if($re['userID'] == $_SESSION["loggedInUserID"])
            {
                $username = $re['username'];
            }
        }

        if(!$pictureThing)
        {
            $pictureThing = "../images/default.png";
        }

        if(!$username)
        {
            $username = "username";
        }

        $sql = "DELETE FROM username WHERE userID = :userID";
        $sql = $db->prepare($sql);
        $sql->bindParam(':userID',$_SESSION["loggedInUserID"]);
        $sql->execute();

        try{
            $sql = "INSERT INTO username VALUES (null,:userID,:username,:picture)";
            $sql = $db->prepare($sql);
            $sql->bindParam(':userID', $_SESSION["loggedInUserID"]);
            $sql->bindParam(':username', $username);
            $sql->bindParam(':picture', $pictureThing);
            $sql->execute();           
        }
        catch(PDOException $e)
        {
            die("There was an error updating your username.");
        }

        $pictureThing = null;
        $username = null;
        
        ?>
        
        <meta http-equiv="refresh" content="0; URL='index.php?action=userSettings'"/>

        <?php
    }

    function profilePicPull($db,$userID){
        $sql = "SELECT * FROM username WHERE userID = :userID";
        $sql = $db->prepare($sql);
        $sql->bindParam(':userID', $_SESSION["loggedInUserID"]);
        $sql->execute();
        $results = $sql->fetchAll(PDO::FETCH_ASSOC);
        
        foreach($results as $re)
        {
            if($re['userID'] == $_SESSION['loggedInUserID'])
            {
                return $re['profilePicture'];
            }
        }

        return "images/default.png";
    }

    function updateEmailFunc($db,$email,$pword){
        $sql = "SELECT * FROM users WHERE userID = :userID";
        $sql = $db->prepare($sql);
        $sql->bindParam(':userID',$_SESSION["loggedInUserID"]);
        $sql->execute();
        $results = $sql->fetchAll(PDO::FETCH_ASSOC);

        $pwordHash = hash('sha1',$pword);

        foreach($results as $re)
        {
            if($re['userID'] == $_SESSION["loggedInUserID"])
            {
                $pwordDB = $re['password'];
                $userCreationDate = $re['userCreationDate'];
            }
        }
        
        if($pwordHash = $pwordDB){
            try{
                $sql = "UPDATE users SET email = :email, password = :password, userCreationDate = :UCR WHERE userID = :userID";
                $sql = $db->prepare($sql);
                $sql->bindParam(':email',$email);
                $sql->bindParam(':password',$pwordHash);
                $sql->bindParam(':UCR',$userCreationDate);
                $sql->bindParam(':userID',$_SESSION["loggedInUserID"]);
                $sql->execute();
            }
            catch(PDOException $e){
                die("There was an error updating your email address.");
            }
            ?>
            
            <meta http-equiv="refresh" content="0; URL='index.php?action=userSettings'"/>
            
            <?php
        }
        else{
            echo "Password incorrect.";

            include_once("index.php?action=updateEmail");
        }

    }

    function updatePasswordFunc($db,$oldPass,$pword,$pwordConfirm){
        $sql = "SELECT * FROM users WHERE userID = :userID";
        $sql = $db->prepare($sql);
        $sql->bindParam(':userID',$_SESSION["loggedInUserID"]);
        $sql->execute();
        $results = $sql->fetchAll(PDO::FETCH_ASSOC);

        $oldPassHash = hash('sha1',$oldPass);
        $pwordHash = hash('sha1',$pword);
        $pwordConfirmHash = hash('sha1',$pwordConfirm);

        foreach($results as $re)
        {
            if($re['userID'] == $_SESSION["loggedInUserID"])
            {
                $email = $re['email'];
                $pwordDB = $re['password'];
                $userCreationDate = $re['userCreationDate'];
            }
        }
        
        if($oldPassHash = $pwordDB){
            if($pwordHash == $pwordConfirmHash){
                try{
                    $sql = "UPDATE users SET email = :email, password = :password, userCreationDate = :UCR WHERE userID = :userID";
                    $sql = $db->prepare($sql);
                    $sql->bindParam(':email',$email);
                    $sql->bindParam(':password',$pwordHash);
                    $sql->bindParam(':UCR',$userCreationDate);
                    $sql->bindParam(':userID',$_SESSION["loggedInUserID"]);
                    $sql->execute();
                }
                catch(PDOException $e){
                    die("There was an error updating your email address.");
                }
                ?>
                
                <meta http-equiv="refresh" content="0; URL='index.php?action=userSettings'"/>
                
                <?php
            }
            else{
                echo "New passwords do not match.";
            }
        }
        else{
            echo "Password incorrect.";

            include_once("index.php?action=updateEmail");
        }

    }

    function deleteAccountFunc($db,$uid){
        $sql = $db->prepare("DELETE FROM balance WHERE userID = $uid");
        $sql->bindParam(':userid', $uid,PDO::PARAM_INT);
        $sql->execute();

        $sql = $db->prepare("DELETE FROM goals WHERE userID = $uid");
        $sql->bindParam(':userid', $uid,PDO::PARAM_INT);
        $sql->execute();

        $sql = $db->prepare("DELETE FROM username WHERE userID = $uid");
        $sql->bindParam(':userid', $uid,PDO::PARAM_INT);
        $sql->execute();

        $sql = $db->prepare("DELETE FROM users WHERE userID = $uid");
        $sql->bindParam(':userid', $uid,PDO::PARAM_INT);
        $sql->execute();
    }

    function submitUsernameAdmin($db,$userID,$username,$picture){
        $sql = "SELECT * FROM username WHERE userID = :userID";
        $sql = $db->prepare($sql);
        $sql->bindParam(':userID',$userID);
        $sql->execute();
        $results = $sql->fetchAll(PDO::FETCH_ASSOC);
        
        if($results)
        {
            $sql = "DELETE FROM username WHERE userID = :userID";
            $sql = $db->prepare($sql);
            $sql->bindParam(':userID',$userID);
            $sql->execute();
        }

        $sql = "INSERT INTO username VALUES (NULL, :userID,:username,:picture)";
        $sql = $db->prepare($sql);
        $sql->bindParam(':userID',$userID);
        $sql->bindParam(':username',$username);
        $sql->bindParam(':picture',$picture);
        $sql->execute();
        ?>
        <meta http-equiv="refresh" content="0; URL='adminCP.php'"/>
        <?php
    }

    function deleteDataFunc($db,$table,$tableID){
        $id = $table . "ID";

        if($table == "users"){
            deleteAccountFunc($db,$tableID);
        }
        else{
            $sql = "DELETE FROM $table WHERE $id = :tableID";
            $sql = $db->prepare($sql);
            $sql->bindParam(':tableID',$tableID);
            $sql->execute();
        }
        

        ?>
        <meta http-equiv="refresh" content="0; URL='admincp.php'"/>
        <?php
    }

    function updateUsernameFunc($db,$usernameID,$userID,$username,$picture){
        move_uploaded_file($_FILES['file']['tmp_name'],"../images/".$_FILES['file']['name']);

        $sql = "UPDATE username SET userID = :userID, username = :username, profilePicture = :profilePicture WHERE usernameID = :usernameID";
        $sql = $db->prepare($sql);
        $sql->bindParam(':usernameID',$usernameID);
        $sql->bindParam(':userID',$userID);
        $sql->bindParam(':username',$username);
        $sql->bindParam(':file',$picture);
        $sql->execute();
    }

    function UpdateBalanceFunc($db,$balanceID,$userID,$title,$amount,$payInterval,$notes,$date){
        $sql = "UPDATE balance SET userID = :userID, Title = :Title, Amount = :Amount, payInterval = :payInterval, Notes = :Notes, Date = :Date WHERE balanceID = :balanceID";
        $sql = $db->prepare($sql);
        $sql->bindParam(':userID',$userID);
        $sql->bindParam(':Title', $title);
        $sql->bindParam(':Amount',$amount);
        $sql->bindParam(':payInterval', $payInterval);
        $sql->bindParam(':Notes', $notes);
        $sql->bindParam(':Date', $date);
        $sql->bindParam(':balanceID',$balanceID);
        $sql->execute();

        ?>
            <meta http-equiv="refresh" content="0; URL='admincp.php?tableSelectList=balance&action=Select+a+Table&action=tableSelectUpdate'"/>
        <?php
    }

    function UpdateGoalsFunc($db,$goalsID,$userID,$title,$amount,$goalDate,$notes,$priority){
        $sql = "UPDATE goals SET userID = :userID, title = :title, amount = :amount, goalDate = :goalDate, notes = :notes, priority = :priority WHERE goalsID = :goalsID";
        $sql = $db->prepare($sql);
        $sql->bindParam(':userID',$userID);
        $sql->bindParam(':title', $title);
        $sql->bindParam(':amount',$amount);
        $sql->bindParam(':goalDate', $goalDate);
        $sql->bindParam(':notes', $notes);
        $sql->bindParam(':priority', $priority);
        $sql->bindParam(':goalsID',$goalsID);
        $sql->execute();

        ?>
            <meta http-equiv="refresh" content="0; URL='admincp.php?tableSelectList=goals&action=Select+a+Table&action=tableSelectUpdate'"/>
        <?php
    }

    function UpdateUsersFunc($db,$userID,$email,$password){
        if($password != ""){
            $pwordHash = hash('sha1', $password);

            $sql = "UPDATE users SET email = :email, password = :password WHERE userID = :userID";
            $sql = $db->prepare($sql);
            $sql->bindParam(':email', $email);
            $sql->bindParam(':password', $pwordHash);
            $sql->bindParam(':userID',$userID);
            $sql->execute();
        }

        if($password == ""){
            $sql = "UPDATE users SET email = :email WHERE userID = :userID";
            $sql = $db->prepare($sql);
            $sql->bindParam(':email', $email);
            $sql->bindParam(':userID',$userID);
            $sql->execute();
        }

        ?>
            <meta http-equiv="refresh" content="0; URL='admincp.php?tableSelectList=users&action=Select+a+Table&action=tableSelectUpdate'"/>
        <?php
    }
    
    
    //testing, fixed
?>
































