<!--Angelo designed the graph page-->
<div id="piechart">
   <?php
      $income = 0;
      $expenses = 0;

      $results = pullTableBalance($db);    
		
      foreach($results as $r) {
        if (($r['Amount'] > 0) && ($r['userID'] == $_SESSION["loggedInUserID"])){
          $income += $r['Amount'];
        }
    
        if (($r['Amount'] < 0) && ($r['userID'] == $_SESSION["loggedInUserID"])){
          $expenses += abs($r['Amount']);
        }
      }
      ?>


  <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>

  <script type="text/javascript">

  //Load google charts
  google.charts.load('current', {'packages':['corechart']});
  google.charts.setOnLoadCallback(drawChart);

  //Draw the chart and set the chart values
  function drawChart() {
    var data = google.visualization.arrayToDataTable([
    ['Task', 'Hours per Day'],
    ['Income', <?php echo $income ?>],
    ['Expenses', <?php echo $expenses ?>],
    ]);

    //Optional; add a title and set the width and height of the chart
    var options = {'title':'Income vs. Expenses', 'width':550, 'height':400, backgroundColor: { fill:'transparent' }, 
    colors: ['#6585bb', '#e6693e'], pieHole:0.4, };

    //Displays the chart
    var chart = new google.visualization.PieChart(document.getElementById('piechart'));
    chart.draw(data, options);
  }

</script>
</div>