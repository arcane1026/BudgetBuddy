<footer>
    <hr>
    <p id="footer">Copyright &copy; <?php echo date('Y'); ?> Chris Peloso, Angelo LaGreca. All rights reserved.</p>
</footer>