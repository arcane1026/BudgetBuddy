<header>
    <?php
    //both of us worked on this
    if(!isset($_SESSION["loggedIn"])){
                    ?>
                    <meta http-equiv="refresh" content="0; URL='landingpage.php'"/>
                    <?php
                }
    ?>
    <?php
	 
	 $profilePicture = profilePicPull($db,$_SESSION["loggedInUserID"]);
	
	?>

    <div id="BBheaderpic">
        <img width="100" height="100" src="../images/<?php echo $profilePicture ?>" alt="profile picture">
    </div>    
     
    

    <div id="BBheaderdiv">
        <div id="BBheaderdiv2">
            <div id="BBlogoHeader">
                <h1 id="headerBB">Budget Buddy</h1>
            </div>

            <div id="BBmottoHeader">
                <h3 id="BBmotto">Keeping track of your finances so you don't have to</h3>
            </div>
        </div>

        <div id="logoutButtonHeader">
            <a id="logoutButton" href="index.php?action=userSettings">Settings</a>
            <a id="logoutButton" href="logout.php">Logout</a>
        </div>
    </div>

    

    <!--<h5>user id: <?php //echo $_SESSION["loggedInUserID"]?></h5>-->

    <div id="headerButtons">
        <a href="index.php">Overview</a><a href="index.php?action=incomePage">Income</a><a href="index.php?action=expensesPage">Expenses</a><a href="index.php?action=goalsPage">Goals</a>
    </div>

    <br>

</header>