<?php
    include_once("header.php");
    //chris designed this
?>

<br><br>
<div id="incomePageContainer">
    <form action="index.php" method="get">
        <table id="incomeTable">


            <tr>
                <th>Title</th>
                <th>Amount</th>
                <th>Interval</th>
                <th>Notes</th>
                <th>Date</th>
            </tr>
            <?php

                foreach($incomeDB as $incomeD)
                {
                    ?>
                    <tr>

                        <td id="incomeTableCOL">

                            <?php

                                echo $incomeD['Title'];

                            ?>

                        </td>

                        <td id="incomeTableCOL">

                            <?php

                            echo $incomeD['Amount'];

                            ?>

                        </td>
                        <td id="incomeTableCOL">

                            <?php

                            echo $incomeD['payInterval'];

                            ?>

                        </td>

                        <td id="incomeTableCOL">

                            <?php

                            echo $incomeD['Notes'];

                            ?>

                        </td>

                        <td id="incomeTableCOL">

                            <?php

                            echo $incomeD['Date'];

                            ?>

                        </td>

                    </tr>

                    <?php
                }
            ?>

            <tr>
                <td>
                    <input type="text" name="titleVar" placeholder="Title" required />
                </td>
                <td>
                    <input type="text" name="amountVar" placeholder="Amount" required />
                </td>
                <td>
                    <input type="text" name="intervalVar" placeholder="Interval" required />
                </td>
                <td>
                    <input type="text" name="notesVar" placeholder="Notes" />
                </td>
                <td>
                    <input type="date" name="dateVar" required />
                </td>
            </tr>

            <tr>
                <td>
                    <input type="submit" name="action" value="Submit">
                    <input type="hidden" name="action" id="expensesButton" value="incomeSubmit">
                </td>
            </tr>


        </table>
    </form>
</div>