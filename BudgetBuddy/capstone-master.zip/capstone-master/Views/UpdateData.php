<!--chris designed this-->
<form action="adminCP.php" method="GET">
    <select name="tableSelectList">
        <option selected="selected">choose an option</option>
        <option value="balance">Balance Table</option>
        <option value="goals">Goals Table</option>
        <option value="username">Username Table</option>
        <option value="users">Users Table</option>
    </select>

    <input type="submit" name="action" value="Select a Table" />
    <input type="hidden" name="action" id="expensesButton" value="tableSelectUpdate">


</form>