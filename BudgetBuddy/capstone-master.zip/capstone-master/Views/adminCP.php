<!DOCTYPE HTML>
<html>
<header>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="stylesheet.css">
    <title>Budget Buddy</title>
</header>
<!--chris designed the admin homepage and CRUD-->
<body>
<h1>Admin Homepage</h1>

<?php
    session_start();

    include_once('db.php');
    include_once('functions.php');
    ?>

        <a href="index.php">Return to website</a>

        <br><br>

    <?php

    if(!($_SESSION["loggedInUserID"] == 1)){
        ?>
        <meta http-equiv="refresh" content="0; URL='index.php'"/>
        <?php
    }


    $action = ( array_key_exists( 'action',$_REQUEST) ? $_REQUEST['action'] : "");

    $userID = filter_input(INPUT_GET, 'userID', FILTER_SANITIZE_STRING) ?? "";
    $title = filter_input(INPUT_GET, 'title', FILTER_SANITIZE_STRING) ?? "";
    $amount = filter_input(INPUT_GET, 'amount', FILTER_SANITIZE_STRING) ?? "";
    $interval = filter_input(INPUT_GET, 'interval', FILTER_SANITIZE_STRING) ?? "";
    $notes = filter_input(INPUT_GET, 'notes', FILTER_SANITIZE_STRING) ?? "";
    $date = filter_input(INPUT_GET, 'date', FILTER_SANITIZE_STRING) ?? "";
    $tableSelectList = filter_input(INPUT_GET, 'tableSelectList', FILTER_SANITIZE_STRING) ?? "";

    $priority = filter_input(INPUT_GET, 'priority', FILTER_SANITIZE_STRING) ?? "";
    $goalDate = filter_input(INPUT_GET, 'goalDate', FILTER_SANITIZE_STRING) ?? "";

    $email = filter_input(INPUT_GET, 'email', FILTER_SANITIZE_STRING) ?? "";
    $password = filter_input(INPUT_GET, 'password', FILTER_SANITIZE_STRING) ?? "";

    $username = filter_input(INPUT_GET, 'username', FILTER_SANITIZE_STRING) ?? "";
    $pictureCategory = filter_input(INPUT_GET, 'pictureCategory', FILTER_SANITIZE_STRING) ?? "";

    $table = filter_input(INPUT_GET, 'table', FILTER_SANITIZE_STRING) ?? "";
    $tableID = filter_input(INPUT_GET, 'tableID', FILTER_SANITIZE_STRING) ?? "";
    
    $picture = filter_input(INPUT_GET, 'file', FILTER_SANITIZE_STRING) ?? "";
    $usernameID = filter_input(INPUT_GET, 'usernameID', FILTER_SANITIZE_STRING) ?? "";
    $balanceID = filter_input(INPUT_GET, 'balanceID', FILTER_SANITIZE_STRING) ?? "";
    $payInterval = filter_input(INPUT_GET, 'payInterval', FILTER_SANITIZE_STRING) ?? "";
    $goalsID = filter_input(INPUT_GET, 'goalsID', FILTER_SANITIZE_STRING) ?? "";




    include_once('adminCPbuttons.php');


    switch($action)
    {
        case "AddData":
            include_once('AddData.php');
            break;
        case "PullData":
            include_once('PullData.php');
            break;
        case "UpdateData":
            include_once('UpdateData.php');
            break;
        case "DeleteData":
            include_once('DeleteData.php');
            break;
        case "balanceTableSelect":
            echo "balance!";
            break;
        case "tableSelect":
            //echo $tableSelectList;
            if($tableSelectList == "users")
            {
                $data = pullTableUsers($db);
            }
            else if($tableSelectList == "balance")
            {
                $data = pullTableBalance($db);
            }
            else if ($tableSelectList == "goals")
            {
                $data = pullTableGoals($db);
            }
            else
            {
                $data = pullTableUsername($db);
            }

            $columnNameArray = getColumnNames($db,$tableSelectList);
            include_once("dataTable.php");
            break;
        case "tableSelectDelete":
            if($tableSelectList == "users")
            {
                $data = pullTableUsers($db);
            }
            else if($tableSelectList == "balance")
            {
                $data = pullTableBalance($db);
            }
            else if ($tableSelectList == "goals")
            {
                $data = pullTableGoals($db);
            }
            else
            {
                $data = pullTableUsername($db);
            }

            $columnNameArray = getColumnNames($db,$tableSelectList);
            include_once("deleteDataTable.php");
            break;
        case "tableSelectUpdate":
            if($tableSelectList == "users")
            {
                $data = pullTableUsers($db);
            }
            else if($tableSelectList == "balance")
            {
                $data = pullTableBalance($db);
            }
            else if ($tableSelectList == "goals")
            {
                $data = pullTableGoals($db);
            }
            else
            {
                $data = pullTableUsername($db);
            }

            $columnNameArray = getColumnNames($db,$tableSelectList);
            include_once("updateDataTable.php");
            break;
        case "deleteTableData":
            deleteDataFunc($db,$table,$tableID);
            break;
        case "updateTableData":
            include_once('updateDataForm.php');
            //updateDataFunc($db,$table,$tableID);
            break;
        case "submitBalance":
            addToBalance($db,$userID,$title,$amount,$interval,$notes,$date);
            break;
        case "submitGoal":
            addToGoals($db,$userID,$title,$amount,$priority,$notes,$goalDate);
            break;
        case "submitUser":
            addToUsers($db,$email,$password);
            break;
        case "submitUsername":
            submitUsernameAdmin($db,$userID,$username,$pictureCategory);
            break;
        case "updateUsername":
            updateUsernameFunc($db,$usernameID,$userID,$username,$picture);
            break;
        case "balanceUpdate":
            updateBalanceFunc($db,$balanceID,$userID,$title,$amount,$payInterval,$notes,$date);
            break;
        case "goalsUpdate":
            updateGoalsFunc($db,$goalsID,$userID,$title,$amount,$goalDate,$notes,$priority);
            break;
        case "usersUpdate":
            updateUsersFunc($db,$userID,$email,$password);
            break;


        default:
    }

?>

</body>
</html>