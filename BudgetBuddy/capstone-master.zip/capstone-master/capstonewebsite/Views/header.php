<!DOCTYPE HTML>
<html>
<head>
   <title>Capstone Documentation</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>	
  <link rel="stylesheet" type="text/css" href="stylesheet.css">
  
</style>
</head>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span> 
      </button>
      <a class="navbar-brand" href="index.php">Budget Buddy Documentation</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li><a href="Team.php">Team</a></li>
        <li><a href="Prop.php">Proposal</a></li> 
        <li><a href="Proto.php">Prototype</a></li> 
		<li><a href="Tech.php">Technical Document</a></li> 
		<li><a href="DB.php">Database</a></li> 
		<li><a href="SS.php">Screenshots</a></li>
		<li><a href="PP.php">PowerPoint</a></li>
		<li><a href="Status.php">Status Reports</a></li>
      </ul>
     
    </div>
  </div>
</nav>