 <h1 id="H1override">NEIT Capstone Project Summer 2018</h1> 
 
 <div id="logodiv">
        <img id="logopic" src="../images/neit.jpg" style = "width: 350px" alt="logo">
    </div>    
	
	<p style="width:210px; background:white; font-weight:bold;">Chris Peloso, Angelo LaGreca</p>