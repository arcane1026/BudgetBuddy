<?php
    include_once("header.php");
?>

<br><br>


<body id="bootstrap-overrides">
<form action="index.php" method="get">
<div id="docdiv" >
		<iframe id="docOverride" src="..\Documents\slides.pdf" width="1000" height="700">
	</div>
</form>
</body>