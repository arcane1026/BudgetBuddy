<?php
    include_once("header.php");
?>




<h1 id="H1override">Proposal</h1> 


<body>
	<div id="docdiv" >
		<iframe id="docOverride" src="..\Documents\Proposal.pdf" width="1000" height="500">
	</div>
</body>