<?php
    include_once("header.php");
?>

<br><br>

<body id="bootstrap-overrides">
<form action="index.php" method="get">
<div id="team">
    <h2>Status 1</h2>
    <p>Last week, Angelo and I came up with a concept and worked on our prototype, creating a landing page for the site. We will begin working on more pages for our prototype week 2, so we can form an idea of what our site is going to look like. There are not many roadblocks as of yet, although we would like to include some form of an infographic on the site somewhere and are not completely sure as to how we are going to do this. This, however, will be an idea that will be included later on in the implementation process.</p>
</div>

<div id="team">
    <h2>Status 2</h2>
    <h3>Last Week:</h3>
        <ul>
            <li>We finished our wireframe.</li>
            <li>Discussed code structure and how we were going to create the site.</li>
            <li>Began to discuss database implementation.</li>
        </ul>
    <h3>Next Week:</h3>
        <ul>
            <li>We will finish our techinical design document</li>
            <li>We'll finish our SQL database design and implementation</li>
        </ul>
    <h3>Roadblocks:</h3>
        <ul>
            <li>None so far, database implementation shouldn't be too complex</li>
        </ul>
</div>

<div id="team">
    <h2>Status 3</h2>
    <h3>Last Week:</h3>
        <ul>
            <li>Completed our technical design document</li>
            <li>Finished our database design and SQL code</li>
        </ul>
    <h3>Next Week:</h3>
        <ul>
            <li>We'll begin the actual coding of our website</li>
            <li>We may attempt to get user login functions working</li>
        </ul>
    <h3>Roadblocks:</h3>
        <ul>
            <li>We aren't sure whether or not to use bootstrap or just plain CSS, considering our mutual inexperience with bootstrap. We'll have to see what happens</li>
        </ul>
</div>

<div id="team">
    <h2>Status 4</h2>
    <h3>Last Week:</h3>
        <ul>
            <li>We got the user login functions working</li>
            <li>Began work on master page layout</li>
            <li>Began work on other database functions</li>
        </ul>
    <h3>Next Week:</h3>
        <ul>
            <li>Attempt to get some of the core pages of the site up and working</li>
            <li>Might consider redesign of the site's look</li>
        </ul>
    <h3>Roadblocks:</h3>
        <ul>
            <li>The info graphic might prove to be a bigger issue than previously anticipated.</li>
        </ul>
</div>

<div id="team">
    <h2>Status 5</h2>
    <h3>Last Week:</h3>
        <ul>
        <li>We began work on coding the website</li>
        <li>We got the database connectivity up and running</li>
        <li>Got user sign-up/login working</li>
        </ul>
    <h3>Next Week:</h3>
        <ul>
        <li>We will begin work on getting the website looking nicer, more like the end result</li>
        <li>We will get the income / expenses tables up and running</li>
        <li>May take a look at bootstrap</li>
        </ul>
    <h3>Roadblocks:</h3>
        <ul>
        <li>I began work on the income table and pulling data from / submitting data to the income table. I had some issues but haven’t really taken a good long look at it, so that may pose a problem but it is unlikely to be any major roadblock.</li>
        <li>The info graphic on the overview page may still be an issue. Angelo has been working on that and seems to be coming along nicely though. We will check with each other this next class and see how things are coming along with both sides.</li>
        <li>Github has not been posing any real issues so far.</li>
        </ul>
</div>

<div id="team">
    <h2>Status 6</h2>
    <h3>Last Week:</h3>
        <ul>
            <li>Finished all database functions</li>
            <li>Made it so balance and goals pull correct data for each individual user</li>
            <li>Redesigned website to look more modern</li>
        </ul>
    <h3>Next Week:</h3>
        <ul>
            <li>Will update the CSS more, look into bootstrap possibly</li>
            <li>Finish the admin page functions. Currently have functions to add data and pull data, have to add delete</li>
        </ul>
    <h3>Roadblocks:</h3>
        <ul>
            <li>Not any so far really, only possible issue might be bootstrap. I haven’t looked into it much so I’ve done most of the site in CSS, if it’s too much of a hassle we may stick with our CSS instead</li>
        </ul>
</div>

<div id="team">
    <h2>Status 7</h2>
    <h3>Last Week:</h3>
        <ul>
            <li>Worked on the user settings page</li>
            <li>Made it so users can enter usernames</li>
            <li>Began work on allowing users to upload photos to the database</li>
        </ul>
    <h3>Next Week:</h3>
        <ul>
            <li>Will make it so users can upload photos</li>
        </ul>
    <h3>Roadblocks:</h3>
        <ul>
            <li>Allowing users to upload their own photos may prove more challenging than previously anticipated, but hopefully it will be done next week with as few problems as possible.</li>
        </ul>
</div>

<div id="team">
    <h2>Status 8</h2>
    <h3>Last Week:</h3>
        <ul>
            <li>Got the picture upload working</li>
            <li>Changed the database layout to include primary keys for the balance, goals, and username table</li>
        </ul>
    <h3>Next Week:</h3>
        <ul>
            <li>May attempt to make the site have a better responsive design</li>
            <li>May make goals appear on the overview page</li>
        </ul>
    <h3>Roadblocks:</h3>
        <ul>
            <li>None so far</li>
        </ul>
</div>

<div id="team">
    <h2>Status 9</h2>
    <h3>Last Week:</h3>
        <ul>
            <li>Forgot to add an update section to the admin page, so that was added</li>
            <li>Fixed some issues with uploading pictures, working great now</li>
        </ul>
    <h3>Next Week:</h3>
        <ul>
            <li>Have a couple bugs to fix with the website, very small things</li>
            <li>Will work on presentation materials, get ready for Wednesday</li>
        </ul>
    <h3>Roadblocks:</h3>
        <ul>
            <li>Hopefully none, everything seems to be working OK.</li>
        </ul>
</div>

<div id="team">
    <h2>Status 10</h2>
    <p>
This quarter has been interesting. Instead of learning through traditionally, I've learning quite a lot about how to solve problems myself and with teammates / classmates. I've learned so much about PHP this quarter; everything I learned last quarter about PHP was really cemented in my head from this project and I had a lot of fun creating it with Angelo. He's helped out a lot, especially when it came to larger, more difficult tasks that we had not encountered before. He was a big help throughout the quarter, and it would be nice to get the chance to work with him again in the future should I go into the Bachelor's degree program.</p>
</div>

<br>
<br>
<br>



</form>
</body>