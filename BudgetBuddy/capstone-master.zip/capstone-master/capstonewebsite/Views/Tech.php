<?php
    include_once("header.php");
?>




<h1 id="H1override">Technical Document</h1> 


<body>
	<div id="docdiv" >
		<iframe id="docOverride" src="..\Documents\techdoc.pdf" width="1000" height="500">
	</div>
</body>