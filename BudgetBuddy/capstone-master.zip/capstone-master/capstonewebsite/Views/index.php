<!DOCTYPE HTML>
<html>



<body id="bootstrap-overrides">
<?php
include_once("header.php");

  $action = ( array_key_exists('action', $_REQUEST) ? $_REQUEST['action'] : "");
   
   ?>
  
   
   <?php
    switch($action)
	 
        {
            case "Team":
                include_once("Team.php");
                break;
		
		 
            case "prop":
                include_once("prop.php");
                break;
		
		 
            case "proto":
                include_once("Proto.php");
                break;
		
		 
            case "tech":
                include_once("Tech.php");
                break;
		
		 
            case "db":
                include_once("DB.php");
                break;
		
		 
            case "SS":
			include_once("landing.php");
                include_once("SS.php");
                break;
		
		 
            case "pp":
                include_once("PP.php");
                break;
		
		
            case "Status":
                include_once("Status.php");
                break;
				
				default:
              
                    include_once("header.php");
                    include_once("home.php");
                
		}
		?>
		
		
</body>
</html>