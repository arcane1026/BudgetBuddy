<?php
    include_once("header.php");
?>

<br><br>
<body id="bootstrap-overrides">

<div id="ssdiv">
<p>Landing Page</p>
   <img id="sspic" src="../images/landing.png"  alt="logo">
</div>

<br>

<div id="ssdiv">
<p>Signup Page</p>
   <img id="sspic" src="../images/signup.png" alt="logo">
</div>

<br>

<div id="ssdiv">
<p>Login Page</p>
   <img id="sspic" src="../images/login.png" alt="logo">
</div>

<br>

<div id="ssdiv">
<p>Overview page</p>
   <img id="sspic" src="../images/Overview.png" alt="logo">
</div>

<br>

<div id="ssdiv">
<p>Expenses Page</p>
   <img id="sspic" src="../images/Expenses.png" alt="logo">
</div>

<br>

<div id="ssdiv">
<p>Income page</p>
   <img id="sspic" src="../images/income.png"  alt="logo">
</div>

<br>

<div id="ssdiv">
<p>Goals Page</p>
   <img id="sspic" src="../images/Goals.png"  alt="logo">
</div>

<br>

<div id="ssdiv">
<p>Admin Page - Create</p>
   <img id="sspic" src="../images/adminPageCreate.png"  alt="logo">
</div>

<br>

<div id="ssdiv">
<p>Admin Page - Read</p>
   <img id="sspic" src="../images/adminPageRead.png"  alt="logo">
</div>

<br>

<div id="ssdiv">
<p>Admin Page - Update</p>
   <img id="sspic" src="../images/adminPageUpdate.png"  alt="logo">
</div>

<br>

<div id="ssdiv">
<p>Admin Page - Delete</p>
   <img id="sspic" src="../images/adminPageDelete.png"  alt="logo">
</div>

<br>
<br>
<br>







</body>