<?php
    include_once("header.php");
?>

<br><br>

 <h1 id="H1override">Team</h1> 
 
<body id="bootstrap-overrides">
<br>
<div id = "team">
<h3><b>Chris Peloso</b></h3>
<br>
<h4>Responsibilities</h4>
<ul>
    <li><b>Lead SQL design</b></li><br>
    <p style="font-style:italic;">I was mainly in charge of taking care of getting the databases set up and running properly, designing how the tables would interact with each other. I consulted Angelo with any changes I would make to the original design we came up with. I also implemented it into our code, so that tables could pull data from the database.</p><br>
    <li><b>Admin Page design</b></li><br>
    <p style="font-style:italic;">I was in charge of creating the backend that would allow admins to alter, add, delete, or simply read any and all entries in the database with ease. This allows admins to keep a good hold on things in the backend, making sure the database is running smoothly.</p><br>
    <li><b>User Experience</b></li><br>
    <p style="font-style:italic;">I helped with making the site navigateable, making it so that users would be able to get to where they needed on the site with ease.</p>

</ul>
</div>
<br>
<br>
<div id = "team">
<h3><b>Angelo LaGreca</b></h3>
<br>
<h4>Responsibilities</h4>
<ul>
    <li><b>User Interface Design</b></li><br>
    <p style="font-style:italic;">Angelo was primarily in charge of keeping the site looking nice, making it so that the design wasn't lacking. Jay's User Interface Design class definitely helped with this; Jay gave excellent pointers as to how to keep the site looking nice and not ugly and dated, like our original design.</p>
    <li><b>Lead Document Design</b></li><br>
    <p style="font-style:italic;">Angelo was mainly in charge of making sure all our documents were kept up to date with what we were doing on the site, and keeping all the documents looking nice. A small role, but very helpful.</p>
    <li><b>Chart Implementation</b></li><br>
    <p style="font-style:italic;">One of Angelo's biggest roles was taking care of the chart and photo implementation. He used the Google Charts API to create an infographic for our site that took in any user's income and expenses, and put that information into the graph to display a visual representation of their financial standing.</p>    
    <li><b>Photo Implementation</b></li><br>
    <p style="font-style:italic;">Another of Angelo's important, quite possibly most important, roles was taking care of user photo uploading. This was critical for our user settings page; allowing users to upload photos was one of the things that we really wanted on the site to help make users feel more "at home." Getting the photos to be uploaded to the site was no easy task, it took Angelo quite a while but having him get this done was a massive help.</p><br>
    
</ul>
</div>
<br><br><br>
</body>