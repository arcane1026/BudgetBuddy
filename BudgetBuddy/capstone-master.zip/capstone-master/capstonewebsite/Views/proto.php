<?php
    include_once("header.php");
?>

<body id="bootstrap-overrides">
    <center><p>The first version of our website prototype before user interface feedback.</p>
    <a href="https://marvelapp.com/3327ee0" target="_blank">Capstone Prototype 1.0</a>

    <div id="ssdiv">
        <p>Original Landing Page</p>
        <img id="sspic" src="../images/LandingPage.jpg" style="width:300px" alt="logo">
    </div>

   <br>
   <br>
   <br>

    <p>The second version of our website prototype after receiving user interface feedback.</p>
    <a href="https://marvelapp.com/42h15ac" target="_blank">Capstone Prototype 2.0</a>

	<div id="ssdiv">
        <p>New Landing Page</p>
        <img id="sspic" src="../images/landing.png"  style="width:300px"  alt="logo">
    </div>

    <br>
    <br>
    <br>

    <div id="ssdiv">
        <p><a href="http://ict.neit.edu/008000399/public_html/capstone/views/index.php" target="_blank">Our Final Site</a><br>
        <a href="http://ict.neit.edu/008000399/public_html/capstone/views/admincp.php" target="_blank">Admin Page</a>
<br>Login info for admin:<br>email:test@test.com<br>password:test</p></center>
    </div>
   
</body>