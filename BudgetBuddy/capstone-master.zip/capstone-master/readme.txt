To run our website, go to 
ict.neit.edu/008000399/public_html/capstone/views/

We have commented throughout our code who was responsible for what parts.
Chris:
adminCP.php & related pages
admin CRUD pages
login.php
logout.php
register.php
updateEmail.php
updatePassword.php
usernameChange.php



Angelo:
graph.php
userPictureChange.php



Both:
CSS stylesheet
functions.php
expenses, income, and goals pages
header.php
index.php
landingPage.php
overviewContent.php
userSettings.php